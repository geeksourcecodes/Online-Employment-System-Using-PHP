<?php include "header.php"?>
<body>
<?php include "session.php"?>
  <div class="container-scroller">
	<?php include "navbar.php"?>
    <!-- partial:../../partials/_navbar.html -->
    
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:../../partials/_sidebar.html -->
      
    <?php include "sidebar.php"?>
      
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:../../partials/_footer.html -->
      <?php include "footer.php"; ?>