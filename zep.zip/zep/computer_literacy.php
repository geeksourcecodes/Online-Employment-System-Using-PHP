<?php include "header.php"?>
<body>

<?php include "session.php"?>
  <div class="container-scroller">
	<?php include "navbar.php"?>
    <!-- partial:../../partials/_navbar.html -->
    
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:../../partials/_sidebar.html -->
      
    <?php include "sidebar.php"?>
      
     <div class="main-panel">
        <div class="content-wrapper">
		<div class="row">
           <div class="col-md-4 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">COMPUTER LITERACY</h4>
                  
                  <form class="forms-sample" method="POST" action="save_computer.php" enctype="multipart/form-data">
                    <div class="form-group">
                      <label>COMPUTER SKILLS</label>
					  <select name="computer_skill"  class="form-control" required>
					  <option value="" selected disabled>--Choose Skill--</option>
					  <option value="MSWORD">MS WORD</option>
					  <option value="MSEXCEL">MS EXCEL</option>
					  <option value="MSPOWERPOINT">MS POWERPOINT</option>
					  <option value="MSPUBLISHER">MS PUBLISHER</option>
					 </select>
                    </div>
                    
                    <div class="form-group">
                      <label>PROFICIENCY</label>
					  <select name="proficiency"  class="form-control" required>
					  <option value="" selected disabled>--Choose Option--</option>
					  <option value="VERY GOOD">VERY GOOD</option>
					  <option value="GOOD">GOOD</option>
					  <option value="FAIR">FAIR</option>
					 </select>
                    </div>
					
					<div class="form-group">
                      <label>Certificate</label>
                  <div class="input-group col-xs-12">
                        <input type="file" name="certificate" class="form-control file-upload-info" placeholder="Upload File">
                        
                      </div>
                    </div>
					
                   
                    <button type="submit" name="submit" class="btn btn-success mr-2">Submit</button>
                    
                  </form>
                </div>
              </div>
            </div>
			<div class="col-md-8 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
				<h4 class="card-title">Saved Computer Skill</h4>
				<div class="table-responsive">
						<table class="table table-hover">
						<thead>
                            <tr>
                                <th><strong>COMPUTER SKILL</strong></th>
                                <th><strong>PROFICIENCY</strong></th>
                                <th colspan="3"><strong>ACTIONS</strong></th>
                               
                            </tr>
                        </thead>	
						<tbody>
						<?php
						$sql = $conn->prepare("select * from computer_literacy where zan_id='$user_zanid'")or die(mysql_error());
						$sql->execute();
						while ($row = $sql->fetch()) {
						$file_n =$row['certificate'];
						if($file_n=='no'){
						$my_file= "n/a";
						}else{
						$my_file = "uploads/computer_skills/".$file_n;
						}
						echo "<tr><td>".$row['computer_skill']."</td><td>".$row['proficiency']."</td><td><a href='$my_file' target='_blank'>view</a></td><td><a href='#'>edit</a></td><td><a href='#'>delete</a></td>";
											
						}
						?>
						</tbody>
						</table>
					</div>
				
				</div></div></div>
			</div>
                  
                </div>
              </div>
            </div>
      
          
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
<?php include"footer.php";?>