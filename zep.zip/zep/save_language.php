<?php 
include "dbcon.php";
include "session.php";
$language_type = $_POST['language_type'];
$speaking = $_POST['speaking'];
$reading = $_POST['reading'];
$writing = $_POST['writing'];


$check = $conn->prepare("select * from language_details where zan_id = '$user_zanid' AND language_type='$language_type' ")or die(mysql_error());
$check->execute();
$num_row = $check->rowcount();
	if ($num_row>0){
		echo "<script>alert('Language Details already exists')</script>";
		echo "<script>window.open('language.php','_self')</script>";	
	}else{
	$conn ->query("INSERT into language_details(zan_id,language_type,speaking,reading,writing)VALUES('$user_zanid','$language_type','$speaking','$reading','$writing')")or die(mysql_error());
		echo "<script>alert('Language Details Saved')</script>";
		echo "<script>window.open('language.php','_self')</script>";
	}
	
?>