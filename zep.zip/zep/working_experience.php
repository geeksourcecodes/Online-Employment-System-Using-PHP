<?php include "header.php"?>
<body>

<?php include "session.php"?>
  <div class="container-scroller">
	<?php include "navbar.php"?>
    <!-- partial:../../partials/_navbar.html -->
    
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:../../partials/_sidebar.html -->
      
    <?php include "sidebar.php"?>
      
     <div class="main-panel">
        <div class="content-wrapper">
          <div class="col-12 grid-margin">
              <div class="card">
                <div class="card-body">
                  
                  <form class="form-sample" method="POST" action="save_working.php">
                    <p class="card-description">Working Experience</p>
					
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-4 col-form-label">ORGANIZATION</label>
                          <div class="col-sm-8">
                            <input type="text" class="form-control" name="working_organization"  required />
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-4 col-form-label">JOB TITLE</label>
                          <div class="col-sm-8">
                            <input type="text" class="form-control" name="working_title"  required/>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
					<div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-4 col-form-label">SUPERVISOR NAME</label>
                          <div class="col-sm-8">
                            <input type="text" name="working_supervisor"  class="form-control" required />
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-4 col-form-label">SUPERVISOR NO.</label>
                          <div class="col-sm-8">
                            <input type="text" name="working_mobile" class="form-control" required />
                          </div>
                        </div>
                      </div>
                      
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-4 col-form-label">START DATE</label>
                          <div class="col-sm-8">
                            <input type="date"  name="working_start" required>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-4 col-form-label">END DATE</label>
                          <div class="col-sm-8">
                            <input type="date"  name="working_end" required>
                          </div>
                        </div>
                      </div>
                    </div>
					<div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-4 col-form-label">CURRENT JOB</label>
                          <div class="col-sm-8">
                            <select class="form-control"name="working_current">
							<option value="" selected disabled>--Choose Option--</option>
                              <option value="YES">YES</option>
                              <option value="NO">NO</option>
							  
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-4 col-form-label">RESPONSIBILITIES</label>
                          <div class="col-sm-8">
                            <textarea class="form-control"  name="working_responsibilities" rows="5"></textarea>
                          </div>
                        </div>
                      </div>
                    </div>
					<center>
					<button type="submit" class="btn btn-success mr-2">Save</button>
					</center>
                    </form>
					<br><hr>
					<p class="card-description">Working Experience Details </p>
                    
					<div class="table-responsive">
						<table class="table table-hover">
						<thead>
                            <tr>
                                
                                <th><strong>ORGANIZATION</strong></th>
                                <th><strong>TITLE</strong></th>
								<th ><strong>SUPERVISOR </strong></th>
								<th ><strong>START DATE</strong></th>
								<th ><strong>END DATE</strong></th>
								<th colspan="2"><strong>ACTIONS</strong></th>
                               
                            </tr>
                        </thead>	
						<tbody>
						<?php
						$sql = $conn->prepare("select * from working_experience where zan_id='$user_zanid'")or die(mysql_error());
						$sql->execute();
						while ($row = $sql->fetch()) {
						
						echo "<tr><td>".$row['working_organization']."</td><td>".$row['working_title']."</td><td>".$row['working_supervisor']."</td><td>".$row['working_start']."</td><td>".$row['working_end']."</td><td><a href='#'>edit</a></td><td><a href='#'>delete</a></td>";
											
						}
						?>
						</tbody>
						</table>
					</div>
				
					
                    </div>
                  
                </div>
              </div>
            </div>
      
          
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
<?php include"footer.php";?>