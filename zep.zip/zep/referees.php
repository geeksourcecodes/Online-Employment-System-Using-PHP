<?php include "header.php"?>
<body>

<?php include "session.php"?>
  <div class="container-scroller">
	<?php include "navbar.php"?>
    <!-- partial:../../partials/_navbar.html -->
    
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:../../partials/_sidebar.html -->
      
    <?php include "sidebar.php"?>
      
     <div class="main-panel">
        <div class="content-wrapper">
          <div class="col-12 grid-margin">
              <div class="card">
                <div class="card-body">
                  
                  <form class="form-sample" method="POST" action="save_referees.php">
                    <p class="card-description">REFEREES</p>
					
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">REFEREE NAME</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="referee_name"  required />
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">ORGANIZATION</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="referee_organization"  required/>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
					<div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">TITLE</label>
                          <div class="col-sm-9">
                            <input type="text" name="referee_title" class="form-control" required />
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">MOBILE NO.</label>
                          <div class="col-sm-9">
                            <input type="text" name="referee_mobile"  class="form-control" required />
                          </div>
                        </div>
                      </div>
                      
                    </div>
                    
					<div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">EMAIL</label>
                          <div class="col-sm-9">
                            <input type="text" name="referee_email"  class="form-control" required />
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">ADDRESS</label>
                          <div class="col-sm-9">
                            <textarea class="form-control"  name="referee_address" rows="5" required></textarea>
                          </div>
                        </div>
                      </div>
                    </div>
					<center>
					<button type="submit" class="btn btn-success mr-2">Save</button>
					</center>
                    </form>
					<br><hr>
					<p class="card-description">Referee Details </p>
                    <div class="table-responsive">
						<table class="table table-hover">
						<thead>
                            <tr>
                                <th><strong>NAME</strong></th>
                                <th><strong>ORGANIZATION</strong></th>
                                <th><strong>TITLE</strong></th>
								<th ><strong>MOBILE</strong></th>
								<th ><strong>EMAIL</strong></th>
								<th colspan="2"><strong>ACTIONS</strong></th>
                               
                            </tr>
                        </thead>	
						<tbody>
						<?php
						$sql = $conn->prepare("select * from referees where zan_id='$user_zanid'")or die(mysql_error());
						$sql->execute();
						while ($row = $sql->fetch()) {
						
						echo "<tr><td>".$row['referee_name']."</td><td>".$row['referee_organization']."</td><td>".$row['referee_title']."</td><td>".$row['referee_mobile']."</td><td>".$row['referee_email']."</td><td><a href='#'>edit</a></td><td><a href='#'>delete</a></td>";
											
						}
						?>
						</tbody>
						</table>
					</div>
					
				
					
                    </div>
                  
                </div>
              </div>
            </div>
      
          
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
<?php include"footer.php";?>