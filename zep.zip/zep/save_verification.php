	<?php
	include "dbcon.php";
	include "session.php";
		if(isset($_POST['upload'])!=""){
		  $education = $_POST['education'];
		  
		  
		  $file_name=$_FILES['verification']['name'];
		  $file_size=$_FILES['verification']['size'];
		  $file_error=$_FILES['verification']['error'];
		  $file_temp=$_FILES['verification']['tmp_name'];
		  
		  $file_ext = explode('.',$file_name);
		  $file_ext = strtolower(end($file_ext));
		  $allowed = array('pdf','jpg','jpeg');
		  $file_name_new = $user_zanid.'-'.$education.'.'.$file_ext;
		  
		  $check = $conn->prepare("select * from other_qualifications where zan_id = '$user_zanid' and qualification_type='VERIFICATION' AND certificate='$file_name_new' and education='$education' ")or die(mysql_error());
		  $check->execute();
		  $num_row = $check->rowcount();
		  if ($num_row>0){
			echo "<script>alert('Verification Certificate Already Exists')</script>";
			echo "<script>window.open('verification.php','_self')</script>";
			}else{
			if(in_array($file_ext,$allowed) ){
			if($file_error==0) {
				 if($file_size<=2097152){
					move_uploaded_file($file_temp,"uploads/verifications/".$file_name_new);
				 }else{
					echo "<script>alert('File Exceeds 2MB')</script>";
					echo "<script>window.open('verification.php','_self')</script>";
				 } 
			}
			  
		  }else{
				echo "<script>alert('Only PDF and JPG Files are allowed')</script>";
				echo "<script>window.open('verification.php','_self')</script>";
		  }
		  
		  $conn ->query("INSERT into other_qualifications(zan_id,education,qualification_type,certificate)VALUES('$user_zanid','$education','VERIFICATION','$file_name_new')")or die(mysql_error());
		  
		echo "<script>alert('Verification Certificate Added Succesfully')</script>";
		echo "<script>window.open('verification.php','_self')</script>";	
		}
		}
	?>