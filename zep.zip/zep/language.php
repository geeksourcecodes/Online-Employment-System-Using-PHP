<?php include "header.php"?>
<body>

<?php include "session.php"?>
  <div class="container-scroller">
	<?php include "navbar.php"?>
    <!-- partial:../../partials/_navbar.html -->
    
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:../../partials/_sidebar.html -->
      
    <?php include "sidebar.php"?>
      
     <div class="main-panel">
        <div class="content-wrapper">
		<div class="row">
           <div class="col-md-4 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">language Proficiency</h4>
                  
                  <form class="forms-sample" method="POST" action="save_language.php">
                    <div class="form-group">
                      <label>LANGUAGE TYPE</label>
					  <select name="language_type" id="language_type" class="form-control">
					  <option value="" selected disabled>--Choose Language--</option>
					  <option value="ENGLISH">ENGLISH</option>
					  <option value="SWAHILI">SWAHILI</option>
					  
					 </select>
                    </div>
                    
                    <div class="form-group">
                      <label>SPEAKING</label>
					  <select  id="" name="speaking" class="form-control">
					  <option value="" selected disabled>--Choose Option--</option>
					  <option value="VERY GOOD">VERY GOOD</option>
					  <option value="GOOD">GOOD</option>
					  <option value="FAIR">FAIR</option>
					 </select>
                    </div>
					<div class="form-group">
                      <label>READING</label>
					  <select  id="" name="reading" class="form-control">
					  <option value="" selected disabled>--Choose Option--</option>
					  <option value="VERY GOOD">VERY GOOD</option>
					  <option value="GOOD">GOOD</option>
					  <option value="FAIR">FAIR</option>
					 </select>
                    </div>
					<div class="form-group">
                      <label>WRITING</label>
					  <select name="writing" id="" class="form-control">
					  <option value="" selected disabled>--Choose Option--</option>
					  <option value="VERY GOOD">VERY GOOD</option>
					  <option value="GOOD">GOOD</option>
					  <option value="FAIR">FAIR</option>
					 </select>
                    </div>
					
                   
                    <button type="submit" class="btn btn-success mr-2">Submit</button>
                    
                  </form>
                </div>
              </div>
            </div>
			<div class="col-md-8 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
				<h4 class="card-title">Saved Language Proficiency</h4>
					<div class="table-responsive">
						<table class="table table-hover">
						<thead>
                            <tr>
                                <th><strong>LANGUAGE</strong></th>
                                <th><strong>SPEAKING</strong></th>
                                <th><strong>READING</strong></th>
                                <th><strong>WRITING</strong></th>
								<th colspan="2"><strong>ACTIONS</strong></th>
                            </tr>
                        </thead>	
						<tbody>
						<?php
						$sql = $conn->prepare("select * from language_details where zan_id='$user_zanid' ")or die(mysql_error());
						$sql->execute();
						while ($row = $sql->fetch()) {
						echo "<tr><td>".$row['language_type']."</td><td>".$row['speaking']."</td><td>".$row['reading']."</td><td>".$row['writing']."</td><td><a href='#'>edit</a></td><td><a href='#'>delete</a></td>";
											
						}
						?>
						</tbody>
						</table>
					</div>
				
				</div>
				</div>
			</div>
			</div>
                  
                </div>
              </div>
            </div>
      
          
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
<?php include"footer.php";?>