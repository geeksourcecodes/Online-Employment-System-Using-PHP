<?php include "header.php"?>
<body>
<?php include "session.php"?>
  <div class="container-scroller">
	<?php include "navbar.php"?>
    <!-- partial:../../partials/_navbar.html -->
    
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:../../partials/_sidebar.html -->
      
    <?php include "sidebar.php"?>

      
     <div class="main-panel">
        <div class="content-wrapper">
		<div class="row">
           <div class="col-md-4 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Academic Qualifications</h4>
                  
                  <form class="forms-sample" method="POST" enctype="multipart/form-data" action="save_transcript.php">
                    <div class="form-group">
                      <label for="exampleInputName1">EDUCATION LEVEL</label> 
                      
					  <select name="education" class="form-control" required>
					  <option value="" selected disabled>--Choose Level--</option>
					  <?php
								$query =$conn->prepare("select * from qualifications where zan_id='$user_zanid'")or die(mysql_error());
								$query->execute();
								$education = $row['education'];
								while($row = $query->fetch()){
															
								echo '<option value="'.$row['education'].'">'.$row['education'].'</option>';
								}
								?>
					  
					  </select>
                    </div>
                    <br>
                    <div class="form-group">
                      <label>TRANSCRIPT (PDF/JPG/JPEG- max 2MB)</label>
                      
                      <div class="input-group col-xs-12">
                        <input type="file" class="form-control file-upload-info" accept="application/pdf" name="transcript" placeholder="Upload File" required>
                        
                      </div>
                    </div>
					<br>
                    <button type="submit" name="upload" class="btn btn-success mr-2">Submit</button>
                    
                  </form>
                </div>
              </div>
            </div>
			<div class="col-md-8 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
				<h4 class="card-title">Saved Academic Transcripts</h4>
				<div class="table-responsive">
						<table class="table table-hover">
						<thead>
                            <tr>
                                <th><strong>EDUCATION</strong></th>
                                <th colspan="3"><strong>ACTIONS</strong></th>
                               
                            </tr>
                        </thead>	
						<tbody>
						<?php
						$sql = $conn->prepare("select * from other_qualifications where zan_id='$user_zanid' AND qualification_type='TRANSCRIPT' ")or die(mysql_error());
						$sql->execute();
						while ($row = $sql->fetch()) {
						$file_n =$row['certificate'];
						$my_file = "uploads/transcripts/".$file_n;
						echo "<tr><td>".$row['education']."</td><td><a href='$my_file' target='_blank'>view</a></td><td><a href='#'>edit</a></td><td><a href='#'>delete</a></td>";
											
						}
						?>
						</tbody>
						</table>
					</div>
					<br>
				
				
				</div></div></div>
			</div>
                  
                </div>
              </div>
            </div>
      
          
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
<?php include"footer.php";?>