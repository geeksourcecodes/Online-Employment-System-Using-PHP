<?php
include "dbcon.php";

$email = $_POST['email'];
$password = $_POST['password'];

$checkapplicant = $conn->prepare("select * from applicants where email = '$email' AND password = '$password' ")or die(mysql_error());
$checkapplicant->execute();
$num_row = $checkapplicant->rowcount();
$row = $checkapplicant ->fetch();
if($num_row > 0)
{
	session_start();
	$_SESSION['id']=$row['app_id'];
	echo "<script>alert('Applicant login Succesfully')</script>";
	echo "<script>window.open('home.php','_self')</script>";
}else{
	echo "<script>alert('Username and password do not exists')</script>";
	echo "<script>window.open('index.php','_self')</script>";
}

?>






