<?php include "header.php"?>
<body>
	   <script>
	$(document).ready(function () {
        $("#region").change(function () {
        var val = $(this).val();
        if (val == "MJINI-MAGHARIBI") {
            $("#district").html("<option value='' selected disabled>--Choose District--</option><option value='MJINI' >MJINI</option><option value='MAGHARIBI-A' >MAGHARIBI-A</option><option value='MAGHARIBI-B' >MAGHARIBI-B</option>");
        } else {
            $("#district").html("<option value='' selected disabled>--Choose Station--</option><option value='CHAKECHAKE' >CHAKECHAKE</option><option value='MKOANI' >MKOANI</option><option value='WETE' >WETE</option><option value='WESHA' >WESHA</option>");
        } 
    });});
</script>
<?php include "session.php"?>
  <div class="container-scroller">
	<?php include "navbar.php"?>
    <!-- partial:../../partials/_navbar.html -->
    
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:../../partials/_sidebar.html -->
      
    <?php include "sidebar.php"?>
      
     <div class="main-panel">
        <div class="content-wrapper">
          <div class="col-12 grid-margin">
              <div class="card">
                <div class="card-body">
                 <?php
					$check = $conn->prepare("select * from person_details where zan_id = '$user_zanid' ")or die(mysql_error());
					$check->execute();
					$num_row = $check->rowcount();
						if ($num_row>0){
						$row =$check ->fetch();
						$fname = $row['fname'];
						$mname = $row['mname'];
						$sname = $row['sname'];
						$gender = $row['gender'];
						$dob = $row['dob'];
						$marital_status = $row['marital_status'];
						$mobile_no = $row['mobile_no'];
						$alt_email = $row['alt_email'];
						$country = $row['country'];
						$region = $row['region'];
						$district = $row['district'];
						$shehia = $row['shehia'];	
						include "personal_1.php";
						}else{
						include "personal_2.php";
						}
				 ?>
                  
                </div>
                  
                </div>
              </div>
            </div>
      
          
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
<?php include"footer.php";?>