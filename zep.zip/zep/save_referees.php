<?php
	include "dbcon.php";
	include "session.php";
	
	$referee_name=$_POST['referee_name'];
	$referee_organization=$_POST['referee_organization'];
	$referee_title=$_POST['referee_title'];
	$referee_mobile=$_POST['referee_mobile'];
	$referee_email=$_POST['referee_email'];
	$referee_address=$_POST['referee_address'];
	
	$check = $conn->prepare("select * from referees where zan_id = '$user_zanid' AND referee_name='$referee_name' AND referee_organization='$referee_organization' ")or die(mysql_error());
	$check->execute();
	$num_row = $check->rowcount();
		if ($num_row>0){
		echo "<script>alert('Referee already exists')</script>";
		echo "<script>window.open('referees.php','_self')</script>";
		}else{
		$conn ->query("INSERT into referees(zan_id,referee_name,referee_organization,referee_title,referee_mobile,referee_email,referee_address)VALUES('$user_zanid','$referee_name','$referee_organization','$referee_title','$referee_mobile','$referee_email','$referee_address')")or die(mysql_error());
		echo "<script>alert('Referee Details Saved')</script>";
		echo "<script>window.open('referees.php','_self')</script>";	
		}

?>