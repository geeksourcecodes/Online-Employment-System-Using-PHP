<form class="form-sample" method="POST" action="save_personal.php">
                    <p class="card-description">Personal Details</p><hr/>
					
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">FIRST NAME</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="fname" id="fname" required />
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">MIDDLE NAME</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="mname" id="mname" required/>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
					<div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">SURNAME</label>
                          <div class="col-sm-9">
                            <input type="text" name="sname" id="sname" class="form-control" required />
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">GENDER</label>
                          <div class="col-sm-9">
                            <select class="form-control" name="gender" required>
							<option value="" selected disabled>--Choose Gender--</option>
                              <option value="MALE">MALE</option>
                              <option value="FEMALE">FEMALE</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">DATE OF BIRTH</label>
                          <div class="col-sm-9">
                            <input type="date" id="dob" name="dob" required>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">MARITAL STATUS</label>
                          <div class="col-sm-9">
                            <select class="form-control" name="marital_status" required>
							<option value="" selected disabled>--Choose Status--</option>
                              <option value="SINGLE">SINGLE</option>
                              <option value="MARRIED">MARRIED</option>
							  <option value="DIVORCED">DIVORCED</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    </div><hr/>
					<p class="card-description">CONTACT DETAILS</p><hr/>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">MOBILE NO</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="mobile_no" id="mobile_no" required />
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">ALTERNATIVE EMAIL</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="alt_email" id="alt_email" required/>
                          </div>
                        </div>
                      </div>
                    </div>
					<div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">COUNTRY</label>
                          <div class="col-sm-9">
                            <select name="country" class="form-control" id="country" required>
								<option value="" selected disabled>--Choose Country--</option>
								<?php
								$query =$conn->prepare("SELECT *  FROM country ORDER BY COUNTRY_ID ASC")or die(mysql_error());
								$query->execute();
								$country_name = $row['COUNTRY_NAME'];
								while($row = $query->fetch()){
															
								echo '<option value="'.$row['COUNTRY_NAME'].'">'.$row['COUNTRY_NAME'].'</option>';
								}
								?>
								</select>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">REGION</label>
                          <div class="col-sm-9">
                            <select class="form-control" name="region" id="region" required>
							 <option value="" selected disabled>--Choose Region--</option>
                              <option value="MJINI-MAGHARIBI">MJINI-MAGHARIBI</option>
                              <option value="KASKAZINI-UNGUJA">KASKAZINI-UNGUJA</option>
							  <option value="KUSINI-UNGUJA">KUSINI-UNGUJA</option>
							  <option value="KASKAZINI-PEMBA">KASKAZINI-PEMBA</option>
							  <option value="KUSINI-PEMBA">KUSINI-PEMBA</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>
					<div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">DISTRICT</label>
                          <div class="col-sm-9">
                            <select class="form-control" name="district" id="district" required>
							<option value="" selected disabled>--Choose District--</option>
							<option value="MJINI-MAGHARIBI">MJINI-MAGHARIBI</option>
                              <option value="KASKAZINI-UNGUJA">KASKAZINI-UNGUJA</option>
							  <option value="KUSINI-UNGUJA">KUSINI-UNGUJA</option>
							  <option value="KASKAZINI-PEMBA">KASKAZINI-PEMBA</option>
							  <option value="KUSINI-PEMBA">KUSINI-PEMBA</option>
							</select>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">SHEHIA</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="shehia" id="shehia" required/>
                          </div>
                        </div>
                      </div>
                    </div>
					<button type="submit" class="btn btn-success mr-2">Save</button>
                    </form>