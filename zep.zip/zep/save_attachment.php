	<?php
	include "dbcon.php";
	include "session.php";
		if(isset($_POST['upload'])!=""){
		  $attachment_type = $_POST['attachment_type'];
		  
		  
		  $file_name=$_FILES['attachment']['name'];
		  $file_size=$_FILES['attachment']['size'];
		  $file_error=$_FILES['attachment']['error'];
		  $file_temp=$_FILES['attachment']['tmp_name'];
		  
		  $file_ext = explode('.',$file_name);
		  $file_ext = strtolower(end($file_ext));
		  $allowed = array('pdf','jpg','jpeg');
		  $file_name_new = $user_zanid.'-'.$attachment_type.'.'.$file_ext;
		  
		  $check = $conn->prepare("select * from other_attachments where zan_id = '$user_zanid' and attachment_type='$attachment_type' ")or die(mysql_error());
		  $check->execute();
		  $num_row = $check->rowcount();
		  if ($num_row>0){
			echo "<script>alert('Attachment  Already Exists')</script>";
			echo "<script>window.open('other_attachments.php','_self')</script>";
			}else{
			if(in_array($file_ext,$allowed) ){
			if($file_error==0) {
				 if($file_size<=2097152){
					move_uploaded_file($file_temp,"uploads/other_attachments/".$file_name_new);
				 }else{
					echo "<script>alert('File Exceeds 2MB')</script>";
					echo "<script>window.open('other_attachments.php','_self')</script>";
				 } 
			}
			  
		  }else{
				echo "<script>alert('Only PDF and JPG Files are allowed')</script>";
				echo "<script>window.open('other_attachments.php','_self')</script>";
		  }
		  
		  $conn ->query("INSERT into other_attachments(zan_id,attachment_type,attachment)VALUES('$user_zanid','$attachment_type','$file_name_new')")or die(mysql_error());
		  
		echo "<script>alert('Attachments Added Succesfully')</script>";
		echo "<script>window.open('other_attachments.php','_self')</script>";	
		}
		}
	?>