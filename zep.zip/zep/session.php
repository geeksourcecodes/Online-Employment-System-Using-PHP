<?php
include'dbcon.php'; 
session_start();

//Check whether the session variable SESS_MEMBER_ID is present or not
if (!isset($_SESSION['id']) || (trim($_SESSION['id']) == '')) { ?>
<script>
window.location = "index.php";
</script>
<?php
}else{
$session_id=$_SESSION['id'];
$resultUser = $conn->prepare("select * from applicants where app_id = '$session_id' ")or die(mysql_error());
$resultUser->execute();
$row = $resultUser->fetch();
$user_email = $row['email'];
$user_zanid = $row['zan_id'];
$user_password = $row['password'];
}
?>

