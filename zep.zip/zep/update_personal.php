<?php 
include "dbcon.php";
include "session.php";
$fname = $_POST['fname'];
$mname = $_POST['mname'];
$sname = $_POST['sname'];
$gender = $_POST['gender'];
$dob = $_POST['dob'];
$marital_status = $_POST['marital_status'];
$mobile_no = $_POST['mobile_no'];
$alt_email = $_POST['alt_email'];
$country = $_POST['country'];
$region = $_POST['region'];
$district = $_POST['district'];
$shehia = $_POST['shehia'];

$conn ->query("UPDATE person_details set fname='$fname',mname='$mname',sname='$sname',gender='$gender',dob='$dob',marital_status='$marital_status',mobile_no='$mobile_no',alt_email='$alt_email',country='$country',region='$region',district='$district',shehia='$shehia' where zan_id='$user_zanid' ")or die(mysql_error());
echo "<script>alert('Personal Details Updated')</script>";
echo "<script>window.open('personal_details.php','_self')</script>";

	
?>