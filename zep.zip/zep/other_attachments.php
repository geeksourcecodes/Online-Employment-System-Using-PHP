<?php include "header.php"?>
<body>

<?php include "session.php"?>
  <div class="container-scroller">
	<?php include "navbar.php"?>
    <!-- partial:../../partials/_navbar.html -->
    
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:../../partials/_sidebar.html -->
      
    <?php include "sidebar.php"?>
      
     <div class="main-panel">
        <div class="content-wrapper">
		<div class="row">
           <div class="col-md-4 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">OTHER ATTACHMENTS</h4>
                  
                  <form class="forms-sample" method="POST" action="save_attachment.php" enctype="multipart/form-data">
                    <div class="form-group">
                      <label>ATTACHMENT TYPE</label>
					  <select name="attachment_type" id="" class="form-control" required>
					  <option value="" selected disabled>--Choose Attachment--</option>
					  <option value="BIRTH">BIRTH CERTIFICATE</option>
					  <option value="CV">CURRICULUM VITAE</option>
					  <option value="RECOMMENDATION">RECOMMENDATION LETTER</option>
					  <option value="ZNID">ZANZIBAR ID</option>
					  <option value="PASSPORT">PASSPORT</option>
					  <option value="LICENSE">DRIVING LICENSE</option>
					  
					 </select>
                    </div>
                    
					<div class="form-group">
                      <label>ATTACHMENT</label>
                      
                      <div class="input-group col-xs-12">
                        <input type="file" class="form-control file-upload-info" name="attachment" placeholder="Upload File" required>
                        
                      </div>
                    </div>
					
                   
                    <button type="submit" name="upload" class="btn btn-success mr-2">Submit</button>
                    
                  </form>
                </div>
              </div>
            </div>
			<div class="col-md-8 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
				<h4 class="card-title">Other Attachment Details</h4>
				<div class="table-responsive">
						<table class="table table-hover">
						<thead>
                            <tr>
                                <th><strong>ATTACHMENT TYPE</strong></th>
                                <th colspan="3"><strong>ACTIONS</strong></th>
                               
                            </tr>
                        </thead>	
						<tbody>
						<?php
						$sql = $conn->prepare("select * from other_attachments where zan_id='$user_zanid'")or die(mysql_error());
						$sql->execute();
						while ($row = $sql->fetch()) {
						$file_n =$row['attachment'];
						
						$my_file = "uploads/other_attachments/".$file_n;
						
						echo "<tr><td>".$row['attachment_type']."</td><td><a href='$my_file' target='_blank'>view</a></td><td><a href='#'>edit</a></td><td><a href='#'>delete</a></td>";
											
						}
						?>
						</tbody>
						</table>
					</div>
				
				</div></div></div>
			</div>
                  
                </div>
              </div>
            </div>
      
          
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
<?php include"footer.php";?>