<?php 
include "dbcon.php";
include "session.php";
$fname = $_POST['fname'];
$mname = $_POST['mname'];
$sname = $_POST['sname'];
$gender = $_POST['gender'];
$dob = $_POST['dob'];
$marital_status = $_POST['marital_status'];
$mobile_no = $_POST['mobile_no'];
$alt_email = $_POST['alt_email'];
$country = $_POST['country'];
$region = $_POST['region'];
$district = $_POST['district'];
$shehia = $_POST['shehia'];

$check = $conn->prepare("select * from person_details where zan_id = '$user_zanid' ")or die(mysql_error());
$check->execute();
$num_row = $check->rowcount();
	if ($num_row>0){
		echo "<script>alert('User already exists')</script>";
		echo "<script>window.open('personal_details.php','_self')</script>";	
	}else{
	$conn ->query("INSERT into person_details(zan_id,fname,mname,sname,gender,dob,marital_status,mobile_no,alt_email,country,region,district,shehia)VALUES('$user_zanid','$fname','$mname','$sname','$gender','$dob','$marital_status','$mobile_no','$alt_email','$country','$region','$district','$shehia')")or die(mysql_error());
		echo "<script>alert('Personal Details Saved')</script>";
		echo "<script>window.open('personal_details.php','_self')</script>";
	}
	
?>