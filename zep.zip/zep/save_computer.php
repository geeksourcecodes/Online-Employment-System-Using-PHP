	<?php
	include "dbcon.php";
	include "session.php";
	$computer_skill = $_POST['computer_skill'];
	$proficiency = $_POST['proficiency'];
	$file_name=$_FILES['certificate']['name'];
	
		if(empty($file_name)){
		$check = $conn->prepare("select * from computer_literacy where zan_id = '$user_zanid' and certificate='no' AND computer_skill='$computer_skill' ")or die(mysql_error());
		  $check->execute();
		  $num_row = $check->rowcount();
		  if ($num_row>0){
			 echo "<script>alert('Computer Skill Already Exists')</script>";
			echo "<script>window.open('computer_literacy.php','_self')</script>";
		  }else{
			$conn ->query("INSERT into computer_literacy(zan_id,computer_skill,proficiency,certificate)VALUES('$user_zanid','$computer_skill','$proficiency','no')")or die(mysql_error());
		  
			echo "<script>alert('Computer SKill Added Succesfully')</script>";
			echo "<script>window.open('computer_literacy.php','_self')</script>";	
		}  
		  }
			
		else{
		  
		  $file_name=$_FILES['certificate']['name'];
		  $file_size=$_FILES['certificate']['size'];
		  $file_error=$_FILES['certificate']['error'];
		  $file_temp=$_FILES['certificate']['tmp_name'];
		  
		  $file_ext = explode('.',$file_name);
		  $file_ext = strtolower(end($file_ext));
		  $allowed = array('pdf','jpg','jpeg');
		  $file_name_new = $user_zanid.'-'.$computer_skill.'.'.$file_ext;
		  
		  $check = $conn->prepare("select * from computer_literacy where zan_id = '$user_zanid' and certificate='$file_name_new' AND computer_skill='$computer_skill' ")or die(mysql_error());
		  $check->execute();
		  $num_row = $check->rowcount();
		  if ($num_row>0){
			echo "<script>alert('Computer Skill Already Exists')</script>";
			echo "<script>window.open('computer_literacy.php','_self')</script>";
			}else{
			if(in_array($file_ext,$allowed) ){
			if($file_error==0) {
				 if($file_size<=2097152){
					move_uploaded_file($file_temp,"uploads/computer_skills/".$file_name_new);
				 }else{
					echo "<script>alert('File Exceeds 2MB')</script>";
					echo "<script>window.open('computer_literacy.php','_self')</script>";
				 } 
			}
			  
		  }else{
				echo "<script>alert('Only PDF and JPG Files are allowed')</script>";
				echo "<script>window.open('computer_literacy.php','_self')</script>";
		  }
		  
		  $conn ->query("INSERT into computer_literacy(zan_id,computer_skill,proficiency,certificate)VALUES('$user_zanid','$computer_skill','$proficiency','$file_name_new')")or die(mysql_error());
		  
		echo "<script>alert('Computer Skill Added Succesfully')</script>";
		echo "<script>window.open('computer_literacy.php','_self')</script>";	
		}
		}
	?>