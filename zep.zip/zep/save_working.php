<?php
	include "dbcon.php";
	include "session.php";
	
	
	$working_organization=$_POST['working_organization'];
	$working_title=$_POST['working_title'];
	$working_supervisor=$_POST['working_supervisor'];
	$working_mobile=$_POST['working_mobile'];
	$working_start=$_POST['working_start'];
	$working_end=$_POST['working_end'];
	$working_current=$_POST['working_current'];
	$working_responsibilities=$_POST['working_responsibilities'];
	
	
	$check = $conn->prepare("select * from working_experience where zan_id = '$user_zanid' AND working_title='$working_title' AND working_organization='$working_organization' ")or die(mysql_error());
	$check->execute();
	$num_row = $check->rowcount();
		if ($num_row>0){
		echo "<script>alert('Working experience already exists')</script>";
		echo "<script>window.open('working_experience.php','_self')</script>";
		}else{
		$conn ->query("INSERT into working_experience(zan_id,working_organization,working_title,working_supervisor,working_mobile,working_start,working_end,working_current,working_responsibilities)VALUES('$user_zanid','$working_organization','$working_title','$working_supervisor','$working_mobile','$working_start','$working_end','$working_current','$working_responsibilities')")or die(mysql_error());
		echo "<script>alert('Working Experience Saved')</script>";
		echo "<script>window.open('working_experience.php','_self')</script>";	
		}

?>